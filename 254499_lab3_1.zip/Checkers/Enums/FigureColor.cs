﻿namespace Checkers.Enums
{
    public enum FigureColor
    {
        White,
        Black
    }
}
