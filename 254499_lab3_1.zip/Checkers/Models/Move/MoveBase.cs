﻿namespace Checkers.Models
{
    public abstract class MoveBase
    {
        public abstract bool IsKillMove { get; }
        public Position From { get; set; }
        public Position Target { get; set; }

        public MoveBase(Position from, Position target)
        {
            From = from;
            Target = target;
        }

        public abstract void MakeMove(Board board);

        public abstract void UndoMove(Board board);

        public abstract string Print(Board board);
    }
}
