﻿namespace Checkers.Enums
{
    public enum GameResult
    {
        WhiteWin,
        BlackWin,
        Draw
    }
}
